import { Button } from "@/components/ui/button"
import { Download, ShieldCheck, Heart } from "lucide-react"

export function FinalCtaSection() {
  return (
    <section className="bg-primary py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary-foreground/20 mb-6">
            <Heart className="h-8 w-8 text-primary-foreground" />
          </div>

          <h2 className="text-3xl font-bold text-primary-foreground md:text-4xl text-balance">
            Your puppy deserves a calm, prepared parent. You deserve to enjoy this.
          </h2>

          <p className="mt-6 text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Stop second-guessing. Stop doom-scrolling. Get the clarity you need so you can focus on what actually
            matters: bonding with your new best friend.
          </p>

          <div className="mt-10 flex flex-col items-center gap-4">
            <Button
              size="lg"
              variant="secondary"
              className="h-14 px-8 text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
              asChild
            >
              <a href="#pricing">
                <Download className="mr-2 h-5 w-5" />
                Get Puppy Prep for $17
              </a>
            </Button>

            <div className="flex items-center gap-2 text-primary-foreground/70 text-sm">
              <ShieldCheck className="h-4 w-4" />
              <span>30-day money-back guarantee • Instant download</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
