import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "When should I get this – before or after my puppy arrives?",
    answer:
      "Ideally, 1-2 weeks before your puppy comes home. The shopping list and prep guides work best when you have time to actually prepare. But the first-week guide is also incredibly helpful even if your puppy is already home – it's never too late to get organized.",
  },
  {
    question: "Is this for a specific breed?",
    answer:
      "No! The advice applies to all breeds and sizes. Whether you're getting a tiny Chihuahua or a large breed like a German Shepherd, the fundamentals of the first week are the same: feeding, potty training, sleep, and settling in.",
  },
  {
    question: "What if I've already read a lot about puppies?",
    answer:
      "Then you'll love how everything is organized in one place. No more keeping 50 tabs open or trying to remember which blog said what. This is your single reference point – especially valuable at 3am when the puppy won't settle.",
  },
  {
    question: "Is this positive reinforcement based?",
    answer:
      "Absolutely. All advice is grounded in modern, science-backed, force-free methods. No dominance theory, no punishment-based techniques. Just kind, effective approaches that build trust with your puppy.",
  },
  {
    question: "How is this different from free content online?",
    answer:
      "Free content is scattered, often contradictory, and you waste hours figuring out what's actually reliable. Puppy Prep is curated, organized, and gives you one clear answer instead of 10 conflicting opinions. Time is precious when you're exhausted.",
  },
  {
    question: "What's the refund policy?",
    answer:
      "30-day no-questions-asked refund. If Puppy Prep doesn't help you feel more prepared and less stressed, just email us and we'll refund you immediately. We're confident it will help, but there's zero risk to you.",
  },
]

export function FaqSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">Questions?</p>
            <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl">Frequently asked questions</h2>
          </div>

          <Accordion type="single" collapsible className="mt-12">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b border-border">
                <AccordionTrigger className="text-left text-lg font-semibold text-foreground hover:text-primary py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-6">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
