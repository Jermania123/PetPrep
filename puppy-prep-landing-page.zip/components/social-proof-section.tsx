import { TrendingUp, Clock, Users, BookOpen } from "lucide-react"

const stats = [
  {
    icon: BookOpen,
    value: "47",
    label: "Pages of actionable guidance",
  },
  {
    icon: Clock,
    value: "15 min",
    label: "Average read time",
  },
  {
    icon: TrendingUp,
    value: "12+ hrs",
    label: "Of research saved",
  },
  {
    icon: Users,
    value: "100%",
    label: "Positive reinforcement methods",
  },
]

const credibilityPoints = [
  "Based on advice from certified dog trainers and veterinarians",
  "Updated regularly with the latest puppy care research",
  "Focused on positive reinforcement – no outdated dominance methods",
  "Created by puppy parents who've been exactly where you are",
]

export function SocialProofSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Why trust us</p>
          <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl text-balance">
            We did the research so you don't have to
          </h2>
        </div>

        {/* Stats grid */}
        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="flex flex-col items-center rounded-2xl border border-border bg-card p-6 text-center"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
              <p className="mt-4 text-3xl font-bold text-foreground">{stat.value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Credibility points */}
        <div className="mt-12 rounded-2xl bg-card border border-border p-6 md:p-8">
          <h3 className="text-lg font-semibold text-foreground text-center mb-6">What makes Puppy Prep different</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {credibilityPoints.map((point, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 mt-0.5">
                  <span className="text-xs font-bold text-primary">{index + 1}</span>
                </div>
                <p className="text-foreground">{point}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
