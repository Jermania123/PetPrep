import { MessageCircleQuestion } from "lucide-react"

const anxiousThoughts = [
  "Is it normal for him to sleep this much?",
  "She won't stop biting me – am I doing something wrong?",
  "Should I let him cry it out or pick him up?",
  "How long can I actually leave her alone?",
  "Is this food okay? The internet says 50 different things...",
  "Why does he bark at everything?",
  "Am I socialising her enough? Too much?",
  "When should I start training?",
  "Is it bad that she sleeps in my bed?",
  "Will this behaviour become a problem later?",
  "Should I be worried about this poop?",
  "Am I ruining my puppy?",
]

export function ProblemSection() {
  return (
    <section className="bg-card py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Sound familiar?</p>
          <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl text-balance">
            The 3am thoughts that won't let you sleep
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">(Even when your puppy finally is)</p>
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-3 md:gap-4">
          {anxiousThoughts.map((thought, index) => (
            <div
              key={index}
              className="flex items-center gap-2 rounded-full border border-border bg-background px-4 py-2.5 text-sm md:text-base text-foreground shadow-sm transition-all hover:shadow-md hover:border-primary/30 hover:bg-primary/5"
            >
              <MessageCircleQuestion className="h-4 w-4 shrink-0 text-primary/60" />
              <span>{thought}</span>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-lg text-muted-foreground max-w-2xl mx-auto">
          You're not alone. Every new puppy parent has these thoughts.
          <strong className="text-foreground">
            {" "}
            The problem isn't you – it's the conflicting advice everywhere you look.
          </strong>
        </p>
      </div>
    </section>
  )
}
