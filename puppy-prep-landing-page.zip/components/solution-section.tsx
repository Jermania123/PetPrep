import { ShieldCheck, ArrowRight, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SolutionSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          {/* Decorative element */}
          <div className="order-2 lg:order-1">
            <div className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-gradient-to-br from-secondary via-accent/20 to-primary/10 shadow-xl">
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-card shadow-lg">
                  <FileText className="h-10 w-10 text-primary" />
                </div>
                <p className="text-xl font-bold text-foreground text-center">Complete Shopping List</p>
                <p className="text-xl font-bold text-foreground text-center">+</p>
                <p className="text-xl font-bold text-foreground text-center">First Week Survival Guide</p>
                <p className="mt-4 text-muted-foreground text-center">Instant PDF download</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <div className="flex items-center gap-2 text-primary">
              <ShieldCheck className="h-6 w-6" />
              <span className="text-sm font-semibold uppercase tracking-wider">The solution</span>
            </div>

            <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl text-balance">
              One calm, clear guide instead of 100 conflicting tabs
            </h2>

            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Puppy Prep is your step-by-step control center for the first week with your puppy. No more doom-scrolling.
              No more second-guessing. Just clear next steps from someone who's been there.
            </p>

            <ul className="mt-8 space-y-4">
              {[
                "Know exactly what to buy (and what's a waste of money)",
                "Day-by-day guidance for the critical first week",
                "What to do when things go wrong (and they will)",
                "Built on positive reinforcement and science-backed methods",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <ArrowRight className="mt-1 h-5 w-5 shrink-0 text-primary" />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>

            <Button size="lg" className="mt-8" asChild>
              <a href="#pricing">See What's Inside</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
