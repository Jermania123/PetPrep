import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, ShieldCheck, Download } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-background">
      {/* Simple header with logo only */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
            <ShieldCheck className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">Puppy Prep</span>
        </div>
      </header>

      <div className="container mx-auto px-4 pb-16 pt-8 md:pb-24 md:pt-12">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          {/* Left column - Copy */}
          <div className="max-w-xl">
            <Badge variant="secondary" className="mb-6 px-4 py-2 text-sm font-medium">
              Trusted by 2,000+ new puppy parents
            </Badge>

            <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl text-balance">
              You're excited. But you really want to <span className="text-primary">get it right.</span>
            </h1>

            <p className="mt-6 text-lg leading-relaxed text-muted-foreground md:text-xl">
              The complete shopping list + do's & don'ts guide that tells you
              <strong className="text-foreground"> exactly what to buy and exactly what to do</strong> before your puppy
              arrives and during the first week.
            </p>

            <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
              <Button
                size="lg"
                className="h-14 px-8 text-lg font-semibold shadow-lg hover:shadow-xl transition-shadow"
                asChild
              >
                <a href="#pricing">
                  <Download className="mr-2 h-5 w-5" />
                  Get Instant Access – $17
                </a>
              </Button>
              <p className="text-sm text-muted-foreground">Instant PDF download • No account needed</p>
            </div>

            {/* Trust indicators */}
            <div className="mt-10 flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>Science-backed advice</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>Positive reinforcement only</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span>30-day money back</span>
              </div>
            </div>
          </div>

          {/* Right column - Decorative element */}
          <div className="relative hidden lg:block">
            <div className="relative aspect-square overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 via-secondary to-accent/30 shadow-2xl">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-primary/20">
                    <ShieldCheck className="h-12 w-12 text-primary" />
                  </div>
                  <p className="text-2xl font-bold text-foreground">47 pages</p>
                  <p className="text-muted-foreground">of calm, clear guidance</p>
                </div>
              </div>
            </div>
            {/* Floating card */}
            <div className="absolute -bottom-6 -left-6 rounded-2xl bg-card p-4 shadow-xl md:p-6">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold text-foreground">15-minute read</p>
                  <p className="text-sm text-muted-foreground">Everything you need to know</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
