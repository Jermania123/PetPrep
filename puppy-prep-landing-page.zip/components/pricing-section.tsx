import { Button } from "@/components/ui/button"
import { CheckCircle, Download, ShieldCheck, Zap } from "lucide-react"

const included = [
  "Complete Shopping Checklist (with links)",
  "Day-by-Day First Week Guide",
  "Do's & Don'ts Master List",
  "Emotional Survival Guide",
  "Printable Fridge Checklists",
  "Lifetime access to updates",
]

export function PricingSection() {
  return (
    <section id="pricing" className="bg-card py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Get started today</p>
          <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl">Less than a bag of premium dog food</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            One small investment now saves you hours of stress and costly mistakes later.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-lg">
          <div className="relative rounded-3xl border-2 border-primary bg-background p-8 shadow-xl md:p-10">
            {/* Popular badge */}
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <span className="inline-flex items-center gap-1 rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">
                <Zap className="h-4 w-4" />
                Most Popular
              </span>
            </div>

            <div className="text-center">
              <h3 className="text-2xl font-bold text-foreground">Puppy Prep Complete Bundle</h3>
              <p className="mt-2 text-muted-foreground">Everything you need for the first week</p>

              {/* Psychological pricing display */}
              <div className="mt-6 flex items-baseline justify-center gap-2">
                <span className="text-lg text-muted-foreground line-through">$34</span>
                <span className="text-5xl font-extrabold text-foreground">$17</span>
              </div>
              <p className="mt-2 text-sm text-primary font-medium">50% off – Limited time only</p>
            </div>

            <ul className="mt-8 space-y-3">
              {included.map((item, index) => (
                <li key={index} className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 shrink-0 text-primary" />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>

            <Button
              size="lg"
              className="mt-8 w-full h-14 text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              <Download className="mr-2 h-5 w-5" />
              Get Instant Access – $17
            </Button>

            {/* Trust microcopy */}
            <div className="mt-6 flex flex-col items-center gap-2 text-center text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-primary" />
                <span>30-day money-back guarantee</span>
              </div>
              <p>Instant PDF download • No account required • Secure checkout</p>
            </div>
          </div>
        </div>

        {/* Social proof under pricing */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            <span className="font-semibold text-foreground">2,000+ puppy parents</span> are already using Puppy Prep
          </p>
        </div>
      </div>
    </section>
  )
}
