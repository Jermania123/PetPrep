import {
  ShoppingBag,
  Calendar,
  AlertTriangle,
  Heart,
  FileText,
  CheckCircle,
  X,
  Clock,
  Youtube,
  Users,
  BookOpen,
} from "lucide-react"

const guides = [
  {
    icon: ShoppingBag,
    title: "Complete Shopping List",
    description:
      "Every essential item you need (and what's optional). Links included. Stop wasting money on stuff that doesn't work.",
    highlights: ["Food & treats", "Crate & bedding", "Toys & enrichment", "Grooming essentials"],
  },
  {
    icon: Calendar,
    title: "First Week Day-by-Day Guide",
    description:
      "Exactly what to do from Day 1 to Day 7. Morning routines, feeding schedules, potty training timelines.",
    highlights: ["Hour-by-hour schedules", "Potty training timeline", "Sleep routines", "Socialisation windows"],
  },
  {
    icon: AlertTriangle,
    title: "Do's & Don'ts Checklist",
    description:
      "The mistakes that create long-term problems – and what to do instead. Save yourself months of correcting bad habits.",
    highlights: [
      "Common first-week mistakes",
      "Biting & mouthing solutions",
      "Crate training tips",
      "When to worry (and when not to)",
    ],
  },
  {
    icon: Heart,
    title: "Emotional Survival Guide",
    description:
      "What to expect when exhaustion hits. Reassurance that you're not failing. Strategies to actually enjoy this time.",
    highlights: ["Puppy blues are real", "Self-care reminders", "When to ask for help", "Celebrating small wins"],
  },
]

const alternatives = [
  {
    icon: Youtube,
    title: "Watch 50+ YouTube videos",
    time: "12+ hours",
    problems: ["Conflicting advice", "Outdated info", "No structure", "Ads everywhere"],
  },
  {
    icon: Users,
    title: "Ask 30 other dog owners",
    time: "Weeks of waiting",
    problems: [
      "Everyone has different opinions",
      "What worked for them might not work for you",
      "Hard to find people with recent experience",
    ],
  },
  {
    icon: BookOpen,
    title: "Read 5 different puppy books",
    time: "20+ hours",
    problems: ["Overwhelming detail", "Often contradictory", "Not actionable enough", "Expensive"],
  },
]

export function WhatYouGetSection() {
  return (
    <section id="whats-inside" className="bg-card py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">What's inside</p>
          <h2 className="mt-4 text-3xl font-bold text-foreground md:text-4xl">
            Everything you need. Nothing you don't.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            A complete PDF package you can reference on your phone at 3am when the puppy won't stop crying.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {guides.map((guide, index) => (
            <div
              key={index}
              className="rounded-2xl border border-border bg-background p-6 md:p-8 transition-shadow hover:shadow-lg"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                <guide.icon className="h-7 w-7 text-primary" />
              </div>

              <h3 className="mt-6 text-xl font-bold text-foreground">{guide.title}</h3>
              <p className="mt-2 text-muted-foreground leading-relaxed">{guide.description}</p>

              <ul className="mt-4 grid grid-cols-2 gap-2">
                {guide.highlights.map((highlight, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-foreground">
                    <CheckCircle className="h-4 w-4 shrink-0 text-primary" />
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bonus callout */}
        <div className="mt-12 rounded-2xl bg-primary/10 p-6 md:p-8">
          <div className="flex flex-col items-center gap-4 text-center md:flex-row md:text-left">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-primary">
              <FileText className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground">Bonus: Printable Checklists</h3>
              <p className="mt-1 text-muted-foreground">
                Stick them on your fridge. Check items off as you go. Feel the satisfaction of being prepared.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-20">
          <div className="mx-auto max-w-3xl text-center mb-12">
            <h3 className="text-2xl font-bold text-foreground md:text-3xl">Or you could...</h3>
          </div>

          <div className="grid gap-6 lg:grid-cols-3 mb-8">
            {alternatives.map((alt, index) => (
              <div key={index} className="rounded-2xl border border-border bg-background p-6 opacity-75">
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                    <alt.icon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{alt.title}</h4>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{alt.time}</span>
                    </div>
                  </div>
                </div>
                <ul className="space-y-2">
                  {alt.problems.map((problem, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <X className="h-4 w-4 shrink-0 text-destructive/60 mt-0.5" />
                      <span>{problem}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* The better option */}
          <div className="rounded-2xl border-2 border-primary bg-primary/5 p-6 md:p-8">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-primary">
                <CheckCircle className="h-8 w-8 text-primary-foreground" />
              </div>
              <div className="text-center md:text-left">
                <h4 className="text-xl font-bold text-foreground">Or get Puppy Prep</h4>
                <p className="mt-1 text-muted-foreground">
                  <strong className="text-foreground">15-minute read.</strong> Everything curated, organised, and ready
                  to use. No conflicting advice. No wasted time. Just clear, actionable guidance.
                </p>
              </div>
              <div className="shrink-0">
                <span className="text-2xl font-bold text-primary">$17</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
